#include "securityStudent.h"



Degree SecurityStudent::getDegreeProgram() {
	return DT;
}